exports.mydt = function()
{
	a=100;
	b=200;
	a=a+b;
	b=a-b;
	a=a-b;
	return "after swap value="+a+"b="+b;
}