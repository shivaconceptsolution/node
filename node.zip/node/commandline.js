/*process.argv.forEach((val, index) => {
  console.log(`${index}: ${val}`)
})*/

const args = process.argv.slice(2)
console.log(args[0])
//console.log(args['name'])
const args1 = require('minimist')(process.argv.slice(2))
console.log(args1['name']) //joe