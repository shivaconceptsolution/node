var fs = require("fs");
var data = fs.readFileSync('efixman.txt');

console.log(data.toString());
console.log("Program Ended");