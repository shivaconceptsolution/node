a=100
b=200
console.log(a,b)
s = "hello"
d=101
f=3.14
console.log('My %s has %d years %f', s,d,f)
console.clear()

x=1
y=101
console.count("x="+x)
console.count("x="+x)
console.count("x="+x)
console.count("y="+y)
console.count("x="+x)

const oranges = ['orange', 'orange']
const apples = ['just one apple']
oranges.forEach(fruit => {
  console.count(fruit)
})
apples.forEach(fruit => {
  console.count(fruit)
})

const function2 = () => console.trace()
const function1 = () => function2()
function2()

const doSomething = () => console.log('test')
const measureDoingSomething = () => {
  console.time('doSomething()')
  //do something, and measure the time it takes
  doSomething()
  console.timeEnd('doSomething()')
}
measureDoingSomething()
console.log('\x1b[33m%s\x1b[0m', 'hi!')
const chalk = require('chalk')
console.log(chalk.yellow('hi!'))
const ProgressBar = require('progress')

const bar = new ProgressBar(':bar', { total: 10 })
const timer = setInterval(() => {
  bar.tick()
  if (bar.complete) {
    clearInterval(timer)
  }
}, 100)