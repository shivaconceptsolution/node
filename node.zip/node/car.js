exports.car = {
  brand: 'Ford',
  model: 'Fiesta'
}

