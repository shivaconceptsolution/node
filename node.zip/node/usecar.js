const c = require('./car')
console.log(c.car.brand)
console.log(c.car.model)