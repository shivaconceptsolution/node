var http = require('http');
var dt = require('./swapmodule');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write("hello" + dt.mydt());
  res.end();
}).listen(8080);

console.log("Program started at localhost 8080");